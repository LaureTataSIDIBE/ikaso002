<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Connexion à la base de données
include "dbconnect.php";

// Vérification des paramètres GET
if (isset($_GET['id_patient'], $_GET['id_medecin'], $_GET['date'], $_GET['heure'])) {
    $id_patient = $_GET['id_patient'];
    $id_medecin = $_GET['id_medecin'];
    $date = $_GET['date'];
    $heure = $_GET['heure'];

    try {
        // Préparer et exécuter la requête d'insertion
        $query = "INSERT INTO rendezvous (id_rendezvous, id_patient, id_medecin, date, heure) VALUES (:id_rendezvous, :id_patient, :id_medecin, :date, :heure)";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':id_rendezvous', $id_rendezvous, PDO::PARAM_INT);
        $stmt->bindParam(':id_patient', $id_patient, PDO::PARAM_INT);
        $stmt->bindParam(':id_medecin', $id_medecin, PDO::PARAM_INT);
        $stmt->bindParam(':date', $date, PDO::PARAM_STR);
        $stmt->bindParam(':heure', $heure, PDO::PARAM_STR);
        $stmt->execute();
        

        // Réponse JSON de succès
        echo json_encode(["success" => "Rendez-vous enregistré avec succès."]);
    } catch (PDOException $e) {
        // Réponse JSON d'erreur en cas d'échec
        http_response_code(500);
        echo json_encode(["error" => "Erreur lors de l'enregistrement : " . $e->getMessage()]);
    }
} else {
    // Réponse JSON si les paramètres GET sont manquants
    http_response_code(400);
    echo json_encode(["error" => "Paramètres manquants (id_patient, id_medecin, date, heure)."]);
}
?>
